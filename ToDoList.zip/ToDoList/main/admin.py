from django.contrib import admin
from .models import Task

# Registering our model that we made in the models.py file, into the admin panel so it shows up alongside 
# Groups and Users on the admin panel of the page 
admin.site.register(Task)