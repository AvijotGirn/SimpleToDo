from django.db import models
from django.contrib.auth.models import User

#======================================================================================
# NOTE: Everytime there is a change made to this (for example, we want to add a new model), we MUST run 
# python manage.py makemigrations
# python manage.py migrate 
# This is done so that the database is updated everytime there is a new model added
#======================================================================================

class Task(models.Model):
    # We want a 1 to many relationship, meaning 1 user can have many items
    # Which is why we use ForeignKey
    # on_delete means, what do we do with a task once the user gets deleted? We want all child tasts to be deleted (which is why
    # we use models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    #Notice we removed null=true and blank=True, this is because we want there to be a title, it cannot be blank 
    title = models.CharField(max_length=200)
    # null and blank are back because this field CAN be blank
    description = models.TextField(null=True, blank=True)
    #When an item is first created, its set to not complete
    complete = models.BooleanField(default=False)
    #Automatically fill in the date and time that the task was created 
    created = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.title
    
    #Ordering by completion 
    class Meta:
        ordering = ['complete']